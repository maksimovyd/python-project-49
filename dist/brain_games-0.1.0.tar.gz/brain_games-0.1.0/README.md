### Hexlet tests and linter status:
[![Actions Status](https://github.com/maksimovyd/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/maksimovyd/python-project-49/actions)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/5b365c56313e0de0eb6b/maintainability)](https://codeclimate.com/github/maksimovyd/python-project-49/maintainability)

### asciinema rec
[![asciinema](https://asciinema.org/a/5fR4OXGqpUKJp3RAh5dox9U7r)]
