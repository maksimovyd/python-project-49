#!/usr/bin/env python3
def print_hello_brain():
    print('Welcome to the Brain Games!')

def main():
    print_hello_brain()

if __name__ == '__main__':
    main()
